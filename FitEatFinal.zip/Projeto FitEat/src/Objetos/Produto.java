/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objetos;

/**
 *
 * @author vinic
 */
public class Produto {
    private String nome;
    private String codigo;
    private String fornecedor;
    private int quantidade;
    
    public Produto(){
    
    };

    public String getNome() {
        return nome;
    }
    public String getCodigo() {
        return codigo;
    }
    public String getFornecedor() {
        return fornecedor;
    }
    public int getQuantidade() {
        return quantidade;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    public void limpaProduto(){
        nome = "";
        codigo = "";
        fornecedor = "";
        quantidade = 0;
    }

    @Override
    public String toString() {
        return this.getNome();
    }
    
    
}
