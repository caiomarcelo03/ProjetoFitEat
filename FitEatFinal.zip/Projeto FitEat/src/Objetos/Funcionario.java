/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objetos;

/**
 *
 * @author vinic
 */
public class Funcionario {
    private String nome;
    private String cpf;
    private String sexo;
    private String cep;
    private String telefone;
    private String email;
    private String funcao;
    
    public Funcionario (){      
    
    }

    public String getNome() {
        return nome;
    }
    public String getCpf() {
        return cpf;
    }
    public String getSexo() {
        return sexo;
    }
    public String getCep() {
        return cep;
    }
    public String getTelefone() {
        return telefone;
    }
    public String getEmail() {
        return email;
    }
    public String getFuncao() {
        return funcao;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    public void setCep(String cep) {
        this.cep = cep;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
    public void limpaFuncionario(){
        nome = "";
        cpf = "";
        sexo = "";
        cep = "";
        telefone = " ";
        email = " ";
        funcao = "";
    }

    @Override
    public String toString() {
        return this.getNome();
    }
    
    
}
