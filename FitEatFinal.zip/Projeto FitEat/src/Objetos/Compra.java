/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Objetos;

/**
 *
 * @author vinic
 */
public class Compra {
    private String produto;
    private String funcionario;
    private int quantidade;

    public Compra(){
    
    }
    
    public String getProduto() {
        return produto;
    }

    public String getFuncionario() {
        return funcionario;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public void setFuncionario(String funcionario) {
        this.funcionario = funcionario;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
    public void limpaCompra(){
        produto = "";
        funcionario = "";
        quantidade = 0;
    }
}
